#include <bits/stdc++.h>
using namespace std;

double f(double x, double y) { return 1 / (1 + x * x) - 2 * y * y; }
double exact(double x) { return x / (1 + x * x); }

int main() {
    double h = 0.1, eps = 0.0005;
    int N = 5;
    vector<double> x(N + 1), y(N + 1);
    x[0] = 0; y[0] = 0;
    for (int i = 0; i < 3; i++) {
        double k1 = h * f(x[i], y[i]);
        double k2 = h * f(x[i] + h / 2, y[i] + k1 / 2);
        double k3 = h * f(x[i] + h / 2, y[i] + k2 / 2);
        double k4 = h * f(x[i] + h, y[i] + k3);
        y[i + 1] = y[i] + (k1 + 2 * k2 + 2 * k3 + k4) / 6;
        x[i + 1] = x[i] + h;
    }
    vector<string> how(N + 1, "RK4 start");
    how[0] = "Initial";
    for (int i = 3; i < N; i++) {
        x[i + 1] = x[i] + h;
        double fi = f(x[i], y[i]), f1 = f(x[i - 1], y[i - 1]), f2 = f(x[i - 2], y[i - 2]), f3 = f(x[i - 3], y[i - 3]);
        double yp = y[i] + h / 24 * (55 * fi - 59 * f1 + 37 * f2 - 9 * f3);
        double yc = yp, prev;
        int k = 0;
        printf("Step x = %.1f: predictor = %.8f\n", x[i + 1], yp);
        do {
            prev = yc;
            yc = y[i] + h / 24 * (9 * f(x[i + 1], prev) + 19 * fi - 5 * f1 + f2);
            k++;
            printf("   corrector %d = %.8f\n", k, yc);
        } while (fabs(yc - prev) >= eps);
        y[i + 1] = yc;
        how[i + 1] = "ABM";
    }
    printf("\n%-6s%-12s%-16s%-16s%-14s\n", "x", "Method", "Numerical", "Exact", "Abs Error");
    printf("----------------------------------------------------------------\n");
    for (int i = 1; i <= N; i++)
        printf("%-6.1f%-12s%-16.8f%-16.8f%-14.6e\n", x[i], how[i].c_str(), y[i], exact(x[i]), fabs(y[i] - exact(x[i])));
    return 0;
}
