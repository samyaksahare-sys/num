#include <bits/stdc++.h>
using namespace std;

vector<double> X = {0.00, 0.08, 0.19, 0.33, 0.50, 0.72, 0.99, 1.31, 1.68, 2.10};
vector<double> Y = {1.000, 1.084, 1.218, 1.406, 1.686, 2.099, 2.687, 3.540, 4.747, 6.404};
vector<double> C;

double P(double x) {
    int n = X.size();
    double r = C[n - 1];
    for (int k = n - 2; k >= 0; k--) r = r * (x - X[k]) + C[k];
    return r;
}

int main() {
    int n = X.size();
    vector<vector<double>> F(n, vector<double>(n, 0));
    for (int i = 0; i < n; i++) F[i][0] = Y[i];
    for (int j = 1; j < n; j++)
        for (int i = 0; i < n - j; i++) F[i][j] = (F[i + 1][j - 1] - F[i][j - 1]) / (X[i + j] - X[i]);
    for (int k = 0; k < n; k++) C.push_back(F[0][k]);

    printf("(a) Divided difference table\n%-6s", "x");
    for (int j = 0; j < n; j++) printf("DD%-10d", j);
    printf("\n");
    for (int i = 0; i < n; i++) {
        printf("%-6.2f", X[i]);
        for (int j = 0; j < n - i; j++) printf("%-12.5f", F[i][j]);
        printf("\n");
    }
    printf("\nP(x) = %.6f", C[0]);
    for (int k = 1; k < n; k++) {
        printf(" %+.6f", C[k]);
        for (int j = 0; j < k; j++) printf("(x-%.2f)", X[j]);
    }
    printf("\n");

    printf("\n(b) Three-point (neighbouring nodes) derivatives\n%-8s%-14s%-14s\n", "x", "f'(x)", "f''(x)");
    double pts[] = {0.33, 0.50, 0.72};
    for (double p : pts) {
        int i = 0;
        while (fabs(X[i] - p) > 1e-12) i++;
        double x0 = X[i - 1], x1 = X[i], x2 = X[i + 1];
        double f01 = (Y[i] - Y[i - 1]) / (x1 - x0);
        double f12 = (Y[i + 1] - Y[i]) / (x2 - x1);
        double f012 = (f12 - f01) / (x2 - x0);
        printf("%-8.2f%-14.6f%-14.6f\n", p, f01 + f012 * (x1 - x0), 2 * f012);
    }

    bool inc = true;
    for (int i = 0; i + 1 < n; i++) if (F[i][1] <= 0) inc = false;
    int imax = max_element(Y.begin(), Y.end()) - Y.begin();
    int imin = min_element(Y.begin(), Y.end()) - Y.begin();
    printf("\n(c) All first divided differences are %s, so f is %s on [%.2f, %.2f].\n", inc ? "positive" : "not all positive",
           inc ? "increasing" : "not monotonic", X.front(), X.back());
    printf("    Maximum f = %.4f at x = %.2f\n    Minimum f = %.4f at x = %.2f\n", Y[imax], X[imax], Y[imin], X[imin]);
    return 0;
}
