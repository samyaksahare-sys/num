#include <bits/stdc++.h>
using namespace std;

int main() {
    vector<double> x = {0.0, 0.3, 0.9, 2.0, 2.4, 3.1, 3.8, 4.2, 4.7, 4.8};
    int n = x.size();
    vector<vector<double>> F(n, vector<double>(n, 0));
    for (int i = 0; i < n; i++) F[i][0] = sin(x[i]);
    for (int j = 1; j < n; j++)
        for (int i = 0; i < n - j; i++) F[i][j] = (F[i + 1][j - 1] - F[i][j - 1]) / (x[i + j] - x[i]);

    printf("(a) Divided difference table\n%-6s", "x");
    for (int j = 0; j < n; j++) printf("DD%-10d", j);
    printf("\n");
    for (int i = 0; i < n; i++) {
        printf("%-6.2f", x[i]);
        for (int j = 0; j < n - i; j++) printf("%-12.6f", F[i][j]);
        printf("\n");
    }

    double xp = 1.8, P = F[0][0], term = 1;
    for (int k = 1; k < n; k++) {
        term *= (xp - x[k - 1]);
        P += F[0][k] * term;
    }
    double ex = sin(xp);
    printf("\n(b) P(1.8) = %.10f\n", P);
    printf("(c) sin(1.8) = %.10f, Absolute error = %.6e\n", ex, fabs(ex - P));
    double prod = 1, fact = 1;
    for (int i = 0; i < n; i++) prod *= (xp - x[i]);
    for (int i = 1; i <= n; i++) fact *= i;
    printf("(d) Error bound |R(1.8)| <= |prod(x - xi)| / %d! = %.6e\n", n, fabs(prod) / fact);
    return 0;
}
