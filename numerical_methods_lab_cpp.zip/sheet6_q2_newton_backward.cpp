#include <bits/stdc++.h>
using namespace std;

double backwardInterp(const vector<double>& x, const vector<double>& y, double xp) {
    int n = x.size();
    vector<vector<double>> B(n, vector<double>(n, 0));
    for (int i = 0; i < n; i++) B[i][0] = y[i];
    for (int j = 1; j < n; j++)
        for (int i = n - 1; i >= j; i--) B[i][j] = B[i][j - 1] - B[i - 1][j - 1];
    double h = x[1] - x[0], v = (xp - x[n - 1]) / h, term = 1, P = B[n - 1][0];
    for (int k = 1; k < n; k++) {
        term *= (v + k - 1) / k;
        P += term * B[n - 1][k];
    }
    return P;
}

int main() {
    vector<double> x = {0, 0.2, 0.4, 0.6, 0.8, 1.0, 1.2, 1.4, 1.6, 1.8, 2.0};
    vector<double> y = {8.0000, 6.4800, 4.7203, 2.7301, 0.6142, -1.0000, 0.4398, 12.9810, 57.8395, 184.0393, 494.0000};
    int n = x.size();

    vector<vector<double>> B(n, vector<double>(n, 0));
    for (int i = 0; i < n; i++) B[i][0] = y[i];
    for (int j = 1; j < n; j++)
        for (int i = n - 1; i >= j; i--) B[i][j] = B[i][j - 1] - B[i - 1][j - 1];
    printf("(a) Backward difference table\n%-6s%-11s", "x", "f");
    for (int j = 1; j < n; j++) printf("Nab^%-7d", j);
    printf("\n");
    for (int i = 0; i < n; i++) {
        printf("%-6.1f", x[i]);
        for (int j = 0; j <= i; j++) printf("%-11.4f", B[i][j]);
        printf("\n");
    }

    double p1 = backwardInterp(x, y, 1.7);
    vector<double> x5(x.end() - 5, x.end()), y5(y.end() - 5, y.end());
    double p2 = backwardInterp(x5, y5, 1.7);
    printf("\n(b) f(1.7) using all 11 points  = %.6f\n", p1);
    printf("(c) f(1.7) using last 5 points  = %.6f\n", p2);
    printf("(d) Difference = %.6f\n", fabs(p1 - p2));
    printf("Using fewer points near x = 1.7 gives a lower-degree local polynomial; the full high-degree\n");
    printf("polynomial includes distant points and may oscillate, so the two estimates differ.\n");
    return 0;
}
