#include <bits/stdc++.h>
using namespace std;

double phi(double x) { return (3 + cos(x)) / 2; }
double f(double x) { return 2 * x - 3 - cos(x); }

int main() {
    double x0 = 1.5, tol = 1e-6;

    printf("Fixed Point Iteration\n%-6s%-16s%-16s%-16s%-16s\n", "Iter", "x_n", "phi(x_n)", "f(x_n)", "Error");
    printf("----------------------------------------------------------------------\n");
    double x = x0;
    int it1 = 0;
    while (true) {
        double xn = phi(x);
        double err = fabs(xn - x);
        it1++;
        printf("%-6d%-16.10f%-16.10f%-16.6e%-16.6e\n", it1, x, xn, f(x), err);
        x = xn;
        if (err < tol) break;
    }
    double root1 = x;

    printf("\nAitken's Delta^2 Method\n%-6s%-16s%-16s%-16s%-16s\n", "Iter", "x_n", "phi(x_n)", "f(x_n)", "Error");
    printf("----------------------------------------------------------------------\n");
    vector<double> seq = {x0, phi(x0), phi(phi(x0))};
    double prevHat = NAN, hat = x0;
    int it2 = 0;
    while (true) {
        int n = seq.size();
        double a = seq[n - 3], b = seq[n - 2], c = seq[n - 1];
        double d2 = c - 2 * b + a;
        if (fabs(d2) < 1e-15) { hat = c; break; }
        hat = c - (c - b) * (c - b) / d2;
        it2++;
        double err = isnan(prevHat) ? fabs(hat - c) : fabs(hat - prevHat);
        printf("%-6d%-16.10f%-16.10f%-16.6e%-16.6e\n", it2, hat, phi(hat), f(hat), err);
        if (!isnan(prevHat) && err < tol) break;
        prevHat = hat;
        seq.push_back(phi(c));
    }
    double root2 = hat;

    printf("\n%-20s%-18s%-12s\n", "Method", "Root", "Iterations");
    printf("%-20s%-18.6f%-12d\n", "Fixed Point", root1, it1);
    printf("%-20s%-18.6f%-12d\n", "Aitken Delta^2", root2, it2);
    printf("\nFixed point converges linearly (|phi'(x)| = |sin x|/2 < 1); Aitken accelerates it and needs fewer iterations.\n");
    return 0;
}
