#include <bits/stdc++.h>
using namespace std;

vector<double> X = {0.0, 0.2, 0.4, 0.6, 0.8, 1.0, 1.2, 1.4, 1.6};
vector<double> Y = {1.000000, 1.040811, 1.168731, 1.411993, 1.810656, 2.718282, 4.060156, 6.550203, 11.023176};

double f(double x) {
    for (size_t i = 0; i < X.size(); i++) if (fabs(X[i] - x) < 1e-9) return Y[i];
    return NAN;
}

int main() {
    double x0 = 1.0, h1 = 0.4, h2 = 0.2;
    double d1 = (f(x0 + h1) - f(x0 - h1)) / (2 * h1);
    double s1 = (f(x0 + h1) - 2 * f(x0) + f(x0 - h1)) / (h1 * h1);
    double d2 = (f(x0 + h2) - f(x0 - h2)) / (2 * h2);
    double s2 = (f(x0 + h2) - 2 * f(x0) + f(x0 - h2)) / (h2 * h2);
    double dr = d2 + (d2 - d1) / 3;
    double sr = s2 + (s2 - s1) / 3;

    printf("(a) h = 0.4: f'(1.0) = %.6f, f''(1.0) = %.6f\n", d1, s1);
    printf("(b) h = 0.2: f'(1.0) = %.6f, f''(1.0) = %.6f\n", d2, s2);
    printf("(c) Richardson (r = 0.5): f'(1.0) = %.6f  [f'' extrapolated = %.6f]\n", dr, sr);
    printf("\n(d) %-22s%-14s%-14s\n", "Method", "f'(1.0)", "Order");
    printf("    %-22s%-14.6f%-14s\n", "Central, h = 0.4", d1, "O(h^2)");
    printf("    %-22s%-14.6f%-14s\n", "Central, h = 0.2", d2, "O(h^2)");
    printf("    %-22s%-14.6f%-14s\n", "Richardson", dr, "O(h^4)");
    printf("Richardson extrapolation cancels the h^2 error term, so it gives the most accurate estimate.\n");
    return 0;
}
