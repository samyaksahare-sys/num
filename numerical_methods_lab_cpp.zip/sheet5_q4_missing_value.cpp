#include <bits/stdc++.h>
using namespace std;

int main() {
    vector<double> x = {1, 2, 3, 4, 5, 6, 7};
    vector<double> y = {3, 11, NAN, 69, 131, 223, 351};
    int n = x.size(), deg = 3, m = -1;
    for (int i = 0; i < n; i++) if (isnan(y[i])) m = i;
    int s = max(0, min(m - deg / 2 - 1, n - deg - 2));
    double sum = 0, coef = 0;
    for (int k = 0; k <= deg + 1; k++) {
        double c = (k % 2 ? -1 : 1);
        for (int t = 0; t < k; t++) c = c * (deg + 1 - t) / (t + 1);
        if (s + k == m) coef = c;
        else sum += c * y[s + k];
    }
    y[m] = -sum / coef;
    printf("Missing value: y(%g) = %g\n\n", x[m], y[m]);

    vector<vector<double>> D(n, vector<double>(n, 0));
    for (int i = 0; i < n; i++) D[i][0] = y[i];
    for (int j = 1; j < n; j++)
        for (int i = 0; i < n - j; i++) D[i][j] = D[i + 1][j - 1] - D[i][j - 1];
    printf("%-8s%-10s", "x", "y");
    for (int j = 1; j <= 4; j++) printf("D^%-8d", j);
    printf("\n");
    for (int i = 0; i < n; i++) {
        printf("%-8g", x[i]);
        for (int j = 0; j <= min(4, n - 1 - i); j++) printf("%-10g", D[i][j]);
        printf("\n");
    }
    return 0;
}
