#include <bits/stdc++.h>
using namespace std;

int main() {
    double a = 0, b = 2, ya = 1, yb = 2;
    int N = 10, m = N - 1;
    double h = (b - a) / N;
    vector<double> x(N + 1), lo(m), di(m), up(m), r(m), y(N + 1);
    for (int i = 0; i <= N; i++) x[i] = a + i * h;
    for (int i = 0; i < m; i++) {
        lo[i] = 1;
        di[i] = -(2 + h * h / 2);
        up[i] = 1;
        r[i] = h * h * x[i + 1] / 2;
    }
    r[0] -= ya;
    r[m - 1] -= yb;
    for (int i = 1; i < m; i++) {
        double w = lo[i] / di[i - 1];
        di[i] -= w * up[i - 1];
        r[i] -= w * r[i - 1];
    }
    y[0] = ya;
    y[N] = yb;
    y[m] = r[m - 1] / di[m - 1];
    for (int i = m - 2; i >= 0; i--) y[i + 1] = (r[i] - up[i] * y[i + 2]) / di[i];

    printf("%-6s%-10s%-14s\n", "i", "x_i", "y_i");
    printf("------------------------------\n");
    for (int i = 0; i <= N; i++) printf("%-6d%-10.2f%-14.8f\n", i, x[i], y[i]);
    return 0;
}
