#include <bits/stdc++.h>
using namespace std;

double f(double x, double y) { return x * sqrt(y); }
double exact(double x) { return pow((x * x + 3) / 4, 2); }

int main() {
    double h = 1, x0 = 1, y0 = 1;
    int steps = 3;
    vector<double> xs, ye, ym;
    double x = x0, e = y0, m = y0;
    xs.push_back(x); ye.push_back(e); ym.push_back(m);
    for (int i = 0; i < steps; i++) {
        e = e + h * f(x, e);
        double p = m + h * f(x, m);
        m = m + h / 2 * (f(x, m) + f(x + h, p));
        x += h;
        xs.push_back(x); ye.push_back(e); ym.push_back(m);
    }
    printf("%-6s%-14s%-14s%-14s%-14s%-14s\n", "x", "Euler", "Mod. Euler", "Exact", "Err Euler", "Err ModEuler");
    printf("------------------------------------------------------------------------------\n");
    int ie = 0, im = 0;
    double me = -1, mm = -1;
    for (size_t i = 0; i < xs.size(); i++) {
        double ex = exact(xs[i]), a = fabs(ye[i] - ex), b = fabs(ym[i] - ex);
        if (a > me) { me = a; ie = i; }
        if (b > mm) { mm = b; im = i; }
        printf("%-6.0f%-14.6f%-14.6f%-14.6f%-14.6f%-14.6f\n", xs[i], ye[i], ym[i], ex, a, b);
    }
    printf("\nLargest error: Euler at x = %.0f (%.6f), Modified Euler at x = %.0f (%.6f)\n", xs[ie], me, xs[im], mm);
    return 0;
}
