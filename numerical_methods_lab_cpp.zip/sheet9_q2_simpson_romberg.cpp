#include <bits/stdc++.h>
using namespace std;

double f(double x) { return x * sin(x) * exp(-x); }

double simp13(double a, double b, int n) {
    double h = (b - a) / n, s = f(a) + f(b);
    for (int i = 1; i < n; i++) s += (i % 2 ? 4 : 2) * f(a + i * h);
    return s * h / 3;
}

double simp38(double a, double b, int n) {
    double h = (b - a) / n, s = f(a) + f(b);
    for (int i = 1; i < n; i++) s += (i % 3 ? 3 : 2) * f(a + i * h);
    return 3 * h * s / 8;
}

int main() {
    double a = 0, b = M_PI;
    double exact = 0.5 + exp(-M_PI) * (M_PI + 1) / 2;
    printf("Exact I = 1/2 + e^(-pi)(pi+1)/2 = %.12f\n\n", exact);

    vector<int> ns = {4, 8, 16, 32, 64};
    int m = ns.size();
    printf("(a)\n%-6s%-18s%-14s%-8s%-18s%-14s\n", "n", "Simpson 1/3", "Abs Error", "n'", "Simpson 3/8", "Abs Error");
    vector<vector<double>> R(m, vector<double>(m, 0));
    for (int i = 0; i < m; i++) {
        int n3 = (ns[i] + 2) / 3 * 3;
        double s1 = simp13(a, b, ns[i]), s3 = simp38(a, b, n3);
        R[i][0] = s1;
        printf("%-6d%-18.12f%-14.6e%-8d%-18.12f%-14.6e\n", ns[i], s1, fabs(s1 - exact), n3, s3, fabs(s3 - exact));
    }
    printf("(Simpson 3/8 needs n divisible by 3, so n' = next multiple of 3 is used.)\n");

    for (int j = 1; j < m; j++)
        for (int i = j; i < m; i++) R[i][j] = R[i][j - 1] + (R[i][j - 1] - R[i - 1][j - 1]) / (pow(4, j + 1) - 1);
    printf("\n(b) Romberg refinement of Simpson 1/3 values\n%-6s", "n");
    for (int j = 0; j < m; j++) printf("R(i,%d)%-12s", j, "");
    printf("\n");
    for (int i = 0; i < m; i++) {
        printf("%-6d", ns[i]);
        for (int j = 0; j <= i; j++) printf("%-18.12f", R[i][j]);
        printf("\n");
    }
    printf("\n(c) Romberg best = %.12f, Abs Error = %.6e\n", R[m - 1][m - 1], fabs(R[m - 1][m - 1] - exact));
    return 0;
}
