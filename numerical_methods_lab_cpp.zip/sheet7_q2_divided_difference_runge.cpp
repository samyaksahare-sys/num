#include <bits/stdc++.h>
using namespace std;

double f(double x) { return 1 / (1 + 25 * x * x); }

int main() {
    vector<double> x = {-1.0, -0.85, -0.7, -0.55, -0.4, -0.25, -0.1, 0.05, 0.2, 0.35, 0.5, 0.65, 0.8, 1.0};
    int n = x.size();
    vector<vector<double>> F(n, vector<double>(n, 0));
    for (int i = 0; i < n; i++) F[i][0] = f(x[i]);
    for (int j = 1; j < n; j++)
        for (int i = 0; i < n - j; i++) F[i][j] = (F[i + 1][j - 1] - F[i][j - 1]) / (x[i + j] - x[i]);

    vector<double> pts = {-0.9, -0.6, -0.3, 0, 0.3, 0.6, 0.9};
    printf("%-8s%-16s%-16s%-16s\n", "x", "P(x)", "f(x)", "Abs Error");
    printf("--------------------------------------------------------\n");
    for (double xp : pts) {
        double P = F[0][0], term = 1;
        for (int k = 1; k < n; k++) {
            term *= (xp - x[k - 1]);
            P += F[0][k] * term;
        }
        printf("%-8.2f%-16.10f%-16.10f%-16.6e\n", xp, P, f(xp), fabs(P - f(xp)));
    }
    printf("\n(c) Errors are largest near x = -1 and x = 1: the high-degree polynomial oscillates near the\n");
    printf("endpoints (Runge phenomenon), while it is accurate near the centre.\n");
    return 0;
}
