#include <bits/stdc++.h>
using namespace std;

int main() {
    vector<double> y = {1.0000, 1.6487, 2.7183, 4.4817, 7.3891, 12.1825, 20.0855};
    int n = y.size() - 1;
    double h = 0.5;

    double t = y[0] + y[n];
    for (int i = 1; i < n; i++) t += 2 * y[i];
    t *= h / 2;

    double s13 = y[0] + y[n];
    for (int i = 1; i < n; i++) s13 += (i % 2 ? 4 : 2) * y[i];
    s13 *= h / 3;

    double s38 = y[0] + y[n];
    for (int i = 1; i < n; i++) s38 += (i % 3 ? 3 : 2) * y[i];
    s38 *= 3 * h / 8;

    double exact = exp(3.0) - 1;
    printf("Exact I = e^3 - 1 = %.6f\n\n", exact);
    printf("%-22s%-14s%-14s\n", "Method", "Value", "Abs Error");
    printf("--------------------------------------------------\n");
    printf("%-22s%-14.6f%-14.6f\n", "Trapezoidal", t, fabs(t - exact));
    printf("%-22s%-14.6f%-14.6f\n", "Simpson 1/3", s13, fabs(s13 - exact));
    printf("%-22s%-14.6f%-14.6f\n", "Simpson 3/8", s38, fabs(s38 - exact));
    return 0;
}
