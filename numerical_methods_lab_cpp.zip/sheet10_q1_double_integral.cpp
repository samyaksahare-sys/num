#include <bits/stdc++.h>
using namespace std;

double f(double x, double y) { return exp(-(x * x + y * y)) / (1 + x + y); }

vector<double> weights(int n, int type) {
    vector<double> w(n + 1);
    for (int i = 0; i <= n; i++) {
        if (type == 0) w[i] = (i == 0 || i == n) ? 1 : 2;
        else w[i] = (i == 0 || i == n) ? 1 : (i % 2 ? 4 : 2);
    }
    return w;
}

double integrate(double h, double k, int tx, int ty) {
    int nx = round(1 / h), ny = round(1 / k);
    vector<double> wx = weights(nx, tx), wy = weights(ny, ty);
    double s = 0;
    for (int i = 0; i <= nx; i++)
        for (int j = 0; j <= ny; j++) s += wx[i] * wy[j] * f(i * h, j * k);
    double cx = tx == 0 ? h / 2 : h / 3, cy = ty == 0 ? k / 2 : k / 3;
    return cx * cy * s;
}

int main() {
    double ref = integrate(1.0 / 1000, 1.0 / 1000, 1, 1);
    double T = integrate(0.25, 0.25, 0, 0);
    double S1 = integrate(0.25, 0.25, 1, 1);
    double S2 = integrate(0.25, 0.125, 1, 1);
    double M1 = integrate(0.25, 0.25, 0, 1);
    double M2 = integrate(0.25, 0.25, 1, 0);

    printf("Reference value I = %.10f\n\n", ref);
    printf("%-40s%-10s%-16s%-14s\n", "Method", "Points", "Value", "Abs Error");
    printf("--------------------------------------------------------------------------------\n");
    printf("%-40s%-10d%-16.10f%-14.6e\n", "(a) Trapezoidal h=k=0.25", 25, T, fabs(T - ref));
    printf("%-40s%-10d%-16.10f%-14.6e\n", "(b) Simpson h=k=0.25", 25, S1, fabs(S1 - ref));
    printf("%-40s%-10d%-16.10f%-14.6e\n", "(b) Simpson h=0.25, k=0.125", 45, S2, fabs(S2 - ref));
    printf("%-40s%-10d%-16.10f%-14.6e\n", "(d) Trapezoidal in x, Simpson in y", 25, M1, fabs(M1 - ref));
    printf("%-40s%-10d%-16.10f%-14.6e\n", "(d) Simpson in x, Trapezoidal in y", 25, M2, fabs(M2 - ref));
    printf("\n(c) Simpson's rule (O(h^4)) is far more accurate than the trapezoidal rule (O(h^2)) on the same mesh;\n");
    printf("refining the mesh (more points) further reduces the error. Mixed rules lie in between.\n");
    return 0;
}
