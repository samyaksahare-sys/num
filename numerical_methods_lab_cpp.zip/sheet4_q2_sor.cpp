#include <bits/stdc++.h>
using namespace std;

typedef vector<vector<double>> Mat;
typedef vector<double> Vec;

int sor(const Mat& A, const Vec& b, double w, double tol, Vec& x) {
    int n = A.size();
    x.assign(n, 0);
    for (int k = 1; k <= 10000; k++) {
        double d = 0;
        for (int i = 0; i < n; i++) {
            double s = b[i];
            for (int j = 0; j < n; j++) if (j != i) s -= A[i][j] * x[j];
            double nx = (1 - w) * x[i] + w * s / A[i][i];
            d = max(d, fabs(nx - x[i]));
            x[i] = nx;
        }
        if (d < tol) return k;
    }
    return -1;
}

int main() {
    Mat A = {
        {13, 0, 1, 3, -1, 1, 1, 3},
        {-2, -11, 3, -1, -1, 1, 0, -1},
        {2, 1, -12, 0, 2, 2, -2, 0},
        {1, -3, 0, -15, 2, 1, 0, -3},
        {-3, -1, -1, 3, -16, 0, 0, 3},
        {2, 2, 3, 2, -1, 16, 3, 0},
        {-3, -1, 1, -1, 3, 1, -18, 3},
        {-2, 0, -3, 0, 2, -2, -2, -15}};
    Vec b = {31, 21.5, -2, -35.5, 20.5, 47.5, -7, -4};
    double tol = 1e-5, rho = 0.3343;
    double wopt = 2 / (1 + sqrt(1 - rho * rho));
    printf("(b) omega_opt = %.6f\n\n", wopt);
    double ws[] = {0.5, 1.5, wopt};
    printf("%-12s%-12s%s\n", "omega", "Iterations", "Solution vector");
    printf("--------------------------------------------------------------------------------------------\n");
    for (double w : ws) {
        Vec x;
        int it = sor(A, b, w, tol, x);
        printf("%-12.6f%-12d(", w, it);
        for (int i = 0; i < 8; i++) printf("%.6f%s", x[i], i < 7 ? ", " : ")\n");
    }
    printf("\nExact solution: (1.5, -2, 0.5, 3, -1, 2.5, 0, -0.5)\n");
    return 0;
}
