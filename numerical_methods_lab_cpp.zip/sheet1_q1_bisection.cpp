#include <bits/stdc++.h>
using namespace std;

double f(double x) { return x * x * x - x - 2; }

int main() {
    double a = 1, b = 2, tol = 1e-6, c = a;
    int it = 0;
    printf("%-6s%-14s%-14s%-14s%-14s\n", "Iter", "a", "b", "c", "f(c)");
    while (fabs(b - a) >= tol) {
        c = (a + b) / 2;
        it++;
        printf("%-6d%-14.8f%-14.8f%-14.8f%-14.8e\n", it, a, b, c, f(c));
        if (f(c) == 0) break;
        if (f(a) * f(c) < 0) b = c;
        else a = c;
    }
    printf("\nRoot = %.6f\nTotal iterations = %d\n", c, it);
    return 0;
}
