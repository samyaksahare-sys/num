#include <bits/stdc++.h>
using namespace std;

double f(double x, double y) { return (y * y - 2 * x) / (y * y + x); }

int main() {
    double h = 0.1;
    int N = 15;
    double x = 0, yr = 1, ym = 1;
    printf("%-8s%-18s%-18s%-14s\n", "x", "RK4", "Modified Euler", "Difference");
    printf("----------------------------------------------------------\n");
    for (int i = 1; i <= N; i++) {
        double k1 = h * f(x, yr);
        double k2 = h * f(x + h / 2, yr + k1 / 2);
        double k3 = h * f(x + h / 2, yr + k2 / 2);
        double k4 = h * f(x + h, yr + k3);
        yr += (k1 + 2 * k2 + 2 * k3 + k4) / 6;
        double p = ym + h * f(x, ym);
        ym += h / 2 * (f(x, ym) + f(x + h, p));
        x = i * h;
        if (i % 5 == 0) printf("%-8.1f%-18.10f%-18.10f%-14.6e\n", x, yr, ym, fabs(yr - ym));
    }
    return 0;
}
