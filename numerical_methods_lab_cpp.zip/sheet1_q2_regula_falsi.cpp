#include <bits/stdc++.h>
using namespace std;

double f(double x) { return exp(-x) - x; }

int main() {
    double a = 0, b = 1, tol = 1e-6, c = a, prev = a;
    int it = 0;
    printf("%-6s%-14s%-14s%-14s%-14s\n", "Iter", "a", "b", "c", "f(c)");
    while (true) {
        c = (a * f(b) - b * f(a)) / (f(b) - f(a));
        it++;
        printf("%-6d%-14.8f%-14.8f%-14.8f%-14.8e\n", it, a, b, c, f(c));
        if (fabs(f(c)) < tol || (it > 1 && fabs(c - prev) < tol)) break;
        if (f(a) * f(c) < 0) b = c;
        else a = c;
        prev = c;
    }
    printf("\nRoot = %.6f\nTotal iterations = %d\n", c, it);
    return 0;
}
