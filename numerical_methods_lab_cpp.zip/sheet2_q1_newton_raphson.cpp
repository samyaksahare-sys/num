#include <bits/stdc++.h>
using namespace std;

double f(double x) { return x - cos(x); }
double df(double x) { return 1 + sin(x); }

int main() {
    double x = 0.5, tol = 1e-6;
    int it = 0;
    printf("%-6s%-16s%-16s%-16s%-16s\n", "Iter", "x_n", "f(x_n)", "f'(x_n)", "Error");
    printf("----------------------------------------------------------------------\n");
    while (true) {
        double fx = f(x), dfx = df(x);
        double xn = x - fx / dfx;
        double err = fabs(xn - x);
        it++;
        printf("%-6d%-16.10f%-16.6e%-16.10f%-16.6e\n", it, x, fx, dfx, err);
        x = xn;
        if (err < tol) break;
    }
    printf("\nRoot = %.6f\nTotal iterations = %d\n", x, it);
    return 0;
}
