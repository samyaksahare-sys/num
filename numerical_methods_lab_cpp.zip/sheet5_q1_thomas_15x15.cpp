#include <bits/stdc++.h>
using namespace std;

int main() {
    const int n = 15;
    double a[n] = {0, -1.0, -1.1, -1.3, -1.0, -1.2, -1.5, -1.1, -1.0, -1.4, -1.2, -1.0, -1.3, -1.1, -1.2};
    double b[n] = {4.5, 4.8, 5.0, 4.6, 5.2, 4.9, 5.5, 4.7, 5.0, 4.8, 5.1, 4.6, 5.3, 4.9, 4.5};
    double c[n] = {-1.2, -1.5, -1.2, -1.0, -1.4, -1.1, -1.3, -1.2, -1.5, -1.1, -1.3, -1.2, -1.0, -1.4, 0};
    double d[n] = {10.5, 12.0, -8.5, 15.2, 6.8, -4.0, 22.1, 11.5, -9.3, 14.0, 7.4, -2.5, 18.6, 5.0, 13.2};

    double bb[n], dd[n], x[n];
    copy(b, b + n, bb);
    copy(d, d + n, dd);
    for (int i = 1; i < n; i++) {
        double m = a[i] / bb[i - 1];
        bb[i] -= m * c[i - 1];
        dd[i] -= m * dd[i - 1];
    }
    x[n - 1] = dd[n - 1] / bb[n - 1];
    for (int i = n - 2; i >= 0; i--) x[i] = (dd[i] - c[i] * x[i + 1]) / bb[i];

    printf("Solution vector:\n");
    for (int i = 0; i < n; i++) printf("x%-3d = %.6f\n", i + 1, x[i]);

    double rn = 0;
    for (int i = 0; i < n; i++) {
        double r = d[i] - b[i] * x[i];
        if (i > 0) r -= a[i] * x[i - 1];
        if (i < n - 1) r -= c[i] * x[i + 1];
        rn = max(rn, fabs(r));
    }
    printf("\n||b - Ax||_inf = %.6e\n", rn);
    return 0;
}
