#include <bits/stdc++.h>
using namespace std;

int main() {
    int n;
    cout << "Enter number of data points: ";
    cin >> n;
    vector<double> x(n), y(n);
    cout << "Enter x y pairs:\n";
    for (int i = 0; i < n; i++) cin >> x[i] >> y[i];

    vector<vector<double>> D(n, vector<double>(n, 0));
    for (int i = 0; i < n; i++) D[i][0] = y[i];
    for (int j = 1; j < n; j++)
        for (int i = 0; i < n - j; i++) D[i][j] = D[i + 1][j - 1] - D[i][j - 1];

    printf("\n%-10s%-12s", "x", "y");
    for (int j = 1; j < n; j++) printf("D^%-10d", j);
    printf("\n");
    for (int i = 0; i < n; i++) {
        printf("%-10.4f", x[i]);
        for (int j = 0; j < n - i; j++) printf("%-12.4f", D[i][j]);
        printf("\n");
    }
    return 0;
}
