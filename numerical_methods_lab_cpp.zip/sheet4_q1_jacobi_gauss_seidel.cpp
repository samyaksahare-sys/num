#include <bits/stdc++.h>
using namespace std;

typedef vector<vector<double>> Mat;
typedef vector<double> Vec;

struct Res { bool conv; int iters; Vec x; };

Res iterate(const Mat& A, const Vec& b, bool seidel, double tol, int maxIt) {
    int n = A.size();
    Vec x(n, 0), x30;
    for (int k = 1; k <= maxIt; k++) {
        Vec old = x, nx = x;
        for (int i = 0; i < n; i++) {
            double s = b[i];
            for (int j = 0; j < n; j++) if (j != i) s -= A[i][j] * (seidel ? nx[j] : old[j]);
            nx[i] = s / A[i][i];
        }
        x = nx;
        if (k == 30) x30 = x;
        double d = 0;
        for (int i = 0; i < n; i++) d = max(d, fabs(x[i] - old[i]));
        if (d < tol) return {true, k, x};
        if (!isfinite(d) || d > 1e12) break;
    }
    return {false, 30, x30.empty() ? x : x30};
}

int main() {
    Mat A = {{3, 2, -2, -1, 1}, {0, 4, 1, -2, 1}, {2, -2, 3, -2, 2}, {2, -2, 2, 4, -2}, {-2, -1, 0, 0, 3}};
    Vec b = {4, -1, -15, 12, -10};
    double tol = 1e-5;
    Res r[2] = {iterate(A, b, false, tol, 1000), iterate(A, b, true, tol, 1000)};
    const char* nm[] = {"Jacobi", "Gauss-Seidel"};
    printf("%-15s%-14s%-12s%s\n", "Method", "Status", "Iterations", "Solution vector");
    printf("--------------------------------------------------------------------------------------\n");
    for (int m = 0; m < 2; m++) {
        printf("%-15s%-14s%-12d(", nm[m], r[m].conv ? "Converges" : "Diverges", r[m].iters);
        for (int i = 0; i < 5; i++) printf("%.6f%s", r[m].x[i], i < 4 ? ", " : ")\n");
    }
    printf("\nExact solution: (1, 2, -1, 3, -2)\n");
    return 0;
}
