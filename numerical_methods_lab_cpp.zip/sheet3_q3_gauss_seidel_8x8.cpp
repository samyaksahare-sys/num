#include <bits/stdc++.h>
using namespace std;

int main() {
    const int n = 8;
    double A[n][n] = {
        {15.2, -2.1, 0.5, 1.1, -0.3, 2.0, 0.0, -1.5},
        {-1.0, 18.5, -3.2, 0.0, 2.5, -1.1, 0.8, 0.5},
        {0.5, -2.0, 14.8, -4.1, 1.2, 0.0, -0.9, 2.1},
        {1.1, 0.0, -3.0, 16.4, -2.2, 1.5, -0.5, 0.8},
        {-0.4, 2.2, 1.0, -2.5, 19.1, -3.0, 1.1, 0.0},
        {2.1, -1.0, 0.0, 1.2, -2.8, 17.5, -3.5, 1.0},
        {0.0, 0.9, -1.1, -0.5, 1.5, -3.2, 16.8, -2.2},
        {-1.2, 0.5, 2.0, 0.7, 0.0, 1.1, -2.5, 15.6}};
    double b[n] = {14.9, -22.3, 35.6, -11.2, 42.8, -5.4, 19.1, -28.4};

    bool sdd = true;
    printf("(a) SDD check:\n");
    for (int i = 0; i < n; i++) {
        double s = 0;
        for (int j = 0; j < n; j++) if (j != i) s += fabs(A[i][j]);
        printf("Row %d: |a_ii| = %.2f, sum = %.2f -> %s\n", i + 1, fabs(A[i][i]), s, fabs(A[i][i]) > s ? "OK" : "NO");
        if (fabs(A[i][i]) <= s) sdd = false;
    }
    printf("Matrix is %sstrictly diagonally dominant\n\n", sdd ? "" : "NOT ");

    double x[n] = {0}, tol = 1e-8;
    int it = 0;
    while (true) {
        double mx = 0;
        for (int i = 0; i < n; i++) {
            double old = x[i], s = b[i];
            for (int j = 0; j < n; j++) if (j != i) s -= A[i][j] * x[j];
            x[i] = s / A[i][i];
            mx = max(mx, fabs((x[i] - old) / x[i]));
        }
        it++;
        if (mx < tol) break;
    }
    printf("(b) Total iterations = %d\n\n(c) Solution:\n", it);
    for (int i = 0; i < n; i++) printf("x%d = %.6f\n", i + 1, x[i]);
    printf("\n(d) Residual r = b - Ax:\n");
    double nr = 0;
    for (int i = 0; i < n; i++) {
        double r = b[i];
        for (int j = 0; j < n; j++) r -= A[i][j] * x[j];
        nr += r * r;
        printf("r%d = %.6e\n", i + 1, r);
    }
    printf("\n(e) ||r||_e = %.6e\n", sqrt(nr));
    return 0;
}
