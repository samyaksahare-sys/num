#include <bits/stdc++.h>
using namespace std;

int thomas(vector<double> a, vector<double> b, vector<double> c, vector<double> d, vector<double>& x) {
    int n = b.size();
    if (fabs(b[0]) < 1e-12) return 1;
    for (int i = 1; i < n; i++) {
        double m = a[i] / b[i - 1];
        b[i] -= m * c[i - 1];
        d[i] -= m * d[i - 1];
        if (fabs(b[i]) < 1e-12) return i + 1;
    }
    x.assign(n, 0);
    x[n - 1] = d[n - 1] / b[n - 1];
    for (int i = n - 2; i >= 0; i--) x[i] = (d[i] - c[i] * x[i + 1]) / b[i];
    return 0;
}

int main() {
    vector<pair<string, pair<double, double>>> ps = {
        {"(1/2, 1)", {0.5, 1}}, {"(2, 2)", {2, 2}}, {"(1/5, 1/3)", {1.0 / 5, 1.0 / 3}}, {"(0, 2)", {0, 2}},
        {"(3/2, 1)", {1.5, 1}}, {"(2, 2/3)", {2, 2.0 / 3}}, {"(1, 1)", {1, 1}}};
    printf("%-14s%-12s%-24s%s\n", "(alpha,beta)", "Status", "Failure step", "Solution");
    printf("------------------------------------------------------------------------------------------\n");
    for (auto& p : ps) {
        double al = p.second.first, be = p.second.second;
        vector<double> a = {0, -1, -1, -1}, b = {2, al, be, 2}, c = {-1, -1, -1, 0}, d = {1, 2, 2, 1}, x;
        int f = thomas(a, b, c, d, x);
        if (f) {
            char s[64];
            snprintf(s, sizeof s, "pivot b%d' = 0 (step %d)", f, f - 1);
            printf("%-14s%-12s%-24s%s\n", p.first.c_str(), "Fails", s, "-");
        } else {
            printf("%-14s%-12s%-24s(%.6f, %.6f, %.6f, %.6f)\n", p.first.c_str(), "Succeeds", "-", x[0], x[1], x[2], x[3]);
        }
    }
    printf("\nThomas algorithm fails whenever a modified diagonal entry becomes zero (no pivoting).\n");
    return 0;
}
