#include <bits/stdc++.h>
using namespace std;

double f(double x) { return 1 / (1 + x); }

int main() {
    vector<double> all = {0, 0.35, 0.55, 0.65, 0.88, 1, 1.37, 1.5, 1.91, 2};
    double xp = 1.25;
    int deg = 4;
    vector<double> x = all;
    sort(x.begin(), x.end(), [&](double a, double b) { return fabs(a - xp) < fabs(b - xp); });
    x.resize(deg + 1);
    sort(x.begin(), x.end());

    printf("Nodes used for P4: ");
    for (double v : x) printf("%.2f ", v);
    printf("\n");

    double P = 0;
    for (int i = 0; i <= deg; i++) {
        double L = 1;
        for (int j = 0; j <= deg; j++) if (j != i) L *= (xp - x[j]) / (x[i] - x[j]);
        P += f(x[i]) * L;
    }
    double ex = f(xp);
    printf("(a) P4(1.25) = %.10f\n", P);
    printf("(b) f(1.25)  = %.10f\n", ex);
    printf("(c) Absolute error = %.6e\n", fabs(ex - P));

    double prod = 1;
    for (double v : x) prod *= (xp - v);
    double lo = min(x.front(), xp);
    double maxDeriv = 120.0 / pow(1 + lo, 6);
    double bound = maxDeriv / 120.0 * fabs(prod);
    printf("(d) |f^(5)(xi)| <= 120/(1+%.2f)^6 = %.6f\n", lo, maxDeriv);
    printf("    Error bound |R4(1.25)| <= %.6e\n", bound);
    return 0;
}
