#include <bits/stdc++.h>
using namespace std;

int main() {
    const int n = 3;
    double A[n][n] = {{10, -1, 2}, {-1, 11, -1}, {2, -1, 10}};
    double b[n] = {27, -19, 35};
    double x[n] = {0, 0, 0}, tol = 1e-10;
    int it = 0;
    printf("%-5s%-16s%-16s%-16s%-14s%-14s%-14s\n", "It", "x1", "x2", "x3", "RelErr x1", "RelErr x2", "RelErr x3");
    while (true) {
        double rel[n], mx = 0;
        for (int i = 0; i < n; i++) {
            double old = x[i], s = b[i];
            for (int j = 0; j < n; j++) if (j != i) s -= A[i][j] * x[j];
            x[i] = s / A[i][i];
            rel[i] = fabs((x[i] - old) / x[i]);
            mx = max(mx, rel[i]);
        }
        it++;
        printf("%-5d%-16.10f%-16.10f%-16.10f%-14.4e%-14.4e%-14.4e\n", it, x[0], x[1], x[2], rel[0], rel[1], rel[2]);
        if (mx < tol) break;
    }
    printf("\nTotal iterations = %d\nResidual r = b - Ax:\n", it);
    for (int i = 0; i < n; i++) {
        double r = b[i];
        for (int j = 0; j < n; j++) r -= A[i][j] * x[j];
        printf("r%d = %.6e\n", i + 1, r);
    }
    return 0;
}
