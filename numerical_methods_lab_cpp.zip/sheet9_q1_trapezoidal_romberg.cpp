#include <bits/stdc++.h>
using namespace std;

double f(double x) { return exp(-x * x) / (1 + x * x); }

double trap(double a, double b, int n) {
    double h = (b - a) / n, s = f(a) + f(b);
    for (int i = 1; i < n; i++) s += 2 * f(a + i * h);
    return s * h / 2;
}

double simpson(double a, double b, int n) {
    double h = (b - a) / n, s = f(a) + f(b);
    for (int i = 1; i < n; i++) s += (i % 2 ? 4 : 2) * f(a + i * h);
    return s * h / 3;
}

int main() {
    double a = 0, b = 1;
    double exact = simpson(a, b, 2000000);
    vector<int> ns = {12, 24, 48, 96};
    int m = ns.size();
    vector<vector<double>> R(m, vector<double>(m, 0));
    for (int i = 0; i < m; i++) R[i][0] = trap(a, b, ns[i]);
    for (int j = 1; j < m; j++)
        for (int i = j; i < m; i++) R[i][j] = R[i][j - 1] + (R[i][j - 1] - R[i - 1][j - 1]) / (pow(4, j) - 1);

    printf("Reference value (no elementary antiderivative, high-precision quadrature): I = %.12f\n\n", exact);
    printf("(a) Composite Trapezoidal\n%-6s%-18s%-14s\n", "n", "T(n)", "Abs Error");
    for (int i = 0; i < m; i++) printf("%-6d%-18.12f%-14.6e\n", ns[i], R[i][0], fabs(R[i][0] - exact));

    printf("\n(b) Romberg table\n%-6s", "n");
    for (int j = 0; j < m; j++) printf("R(i,%d)%-12s", j, "");
    printf("\n");
    for (int i = 0; i < m; i++) {
        printf("%-6d", ns[i]);
        for (int j = 0; j <= i; j++) printf("%-18.12f", R[i][j]);
        printf("\n");
    }
    printf("\n(c) %-26s%-18s%-14s\n", "Method", "Value", "Abs Error");
    printf("    %-26s%-18.12f%-14.6e\n", "Trapezoidal (n = 96)", R[m - 1][0], fabs(R[m - 1][0] - exact));
    printf("    %-26s%-18.12f%-14.6e\n", "Romberg (best)", R[m - 1][m - 1], fabs(R[m - 1][m - 1] - exact));
    return 0;
}
