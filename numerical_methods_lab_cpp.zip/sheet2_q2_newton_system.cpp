#include <bits/stdc++.h>
using namespace std;

int main() {
    double x = 1, y = -1.7, tol = 1e-6;
    int it = 0;
    printf("%-6s%-16s%-16s%-16s%-16s%-16s\n", "Iter", "x", "y", "Delta x", "Delta y", "Error");
    printf("--------------------------------------------------------------------------------\n");
    while (true) {
        double F1 = x * x + y * y - 4, F2 = exp(x) + y - 1;
        double a = 2 * x, b = 2 * y, c = exp(x), d = 1;
        double det = a * d - b * c;
        double dx = (-F1 * d + b * F2) / det;
        double dy = (-a * F2 + c * F1) / det;
        x += dx;
        y += dy;
        it++;
        double err = max(fabs(dx), fabs(dy));
        printf("%-6d%-16.10f%-16.10f%-16.6e%-16.6e%-16.6e\n", it, x, y, dx, dy, err);
        if (err < tol) break;
    }
    printf("\nSolution: x = %.6f, y = %.6f\nTotal iterations = %d\n", x, y, it);
    return 0;
}
