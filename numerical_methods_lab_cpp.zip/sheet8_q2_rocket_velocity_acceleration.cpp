#include <bits/stdc++.h>
using namespace std;

vector<double> T = {0, 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000, 1100, 1200};
vector<double> S = {0.0, 4.6, 18.9, 43.7, 80.8, 132.4, 199.7, 284.9, 389.6, 515.8, 665.1, 839.7, 1041.4};
double h = 100;
const int ORD = 4;

vector<double> polyU(int base) {
    vector<double> d(S.begin() + base, S.begin() + base + ORD + 1);
    vector<double> diff;
    for (int k = 0; k <= ORD; k++) {
        diff.push_back(d[0]);
        for (int i = 0; i + 1 < (int)d.size(); i++) d[i] = d[i + 1] - d[i];
        d.pop_back();
    }
    vector<double> res(ORD + 1, 0), term = {1};
    double fact = 1;
    for (int k = 0; k <= ORD; k++) {
        if (k > 0) {
            fact *= k;
            vector<double> nt(term.size() + 1, 0);
            for (size_t i = 0; i < term.size(); i++) {
                nt[i + 1] += term[i];
                nt[i] -= (k - 1) * term[i];
            }
            term = nt;
        }
        for (size_t i = 0; i < term.size(); i++) res[i] += diff[k] * term[i] / fact;
    }
    return res;
}

double evalD(const vector<double>& c, double u, int der) {
    double r = 0;
    for (size_t i = der; i < c.size(); i++) {
        double k = 1;
        for (int j = 0; j < der; j++) k *= (i - j);
        r += c[i] * k * pow(u, i - der);
    }
    return r;
}

double deriv(double t, int der) {
    int n = T.size();
    int base = (int)floor(t / h) - ORD / 2 + 1;
    base = max(0, min(base, n - ORD - 1));
    vector<double> c = polyU(base);
    double u = (t - T[base]) / h;
    return evalD(c, u, der) / pow(h, der);
}

int main() {
    int n = T.size();
    vector<vector<double>> D(n, vector<double>(ORD + 1, 0));
    for (int i = 0; i < n; i++) D[i][0] = S[i];
    for (int j = 1; j <= ORD; j++)
        for (int i = 0; i < n - j; i++) D[i][j] = D[i + 1][j - 1] - D[i][j - 1];
    printf("(a) Forward difference table\n%-8s%-10s%-10s%-10s%-10s%-10s\n", "t", "s", "D1", "D2", "D3", "D4");
    for (int i = 0; i < n; i++) {
        printf("%-8.0f", T[i]);
        for (int j = 0; j <= ORD && i + j < n; j++) printf("%-10.2f", D[i][j]);
        printf("\n");
    }
    vector<double> c = polyU(0);
    printf("\nInterpolating polynomial (u = t/100):\ns(u) = ");
    for (int i = 0; i <= ORD; i++) printf("%+.6f u^%d ", c[i], i);
    printf("\n");

    printf("\n(b) Velocity\n");
    for (double t : {430.0, 670.0, 860.0, 910.0}) printf("v(%4.0f) = %.6f km/s\n", t, deriv(t, 1));
    printf("\n(c) Acceleration\n");
    for (double t : {525.0, 720.0}) printf("a(%4.0f) = %.8f km/s^2\n", t, deriv(t, 2));

    printf("\n(d) Acceleration across the interval:\n");
    double amin = 1e18, amax = -1e18;
    for (double t = 0; t <= 1200; t += 100) {
        double a = deriv(t, 2);
        amin = min(amin, a);
        amax = max(amax, a);
        printf("a(%4.0f) = %.8f\n", t, a);
    }
    printf("Acceleration varies from %.6f to %.6f km/s^2, so the motion is %s.\n", amin, amax,
           fabs(amax - amin) < 1e-4 ? "uniformly accelerated" : "NOT uniformly accelerated");
    return 0;
}
