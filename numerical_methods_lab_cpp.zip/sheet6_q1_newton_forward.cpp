#include <bits/stdc++.h>
using namespace std;

int main() {
    int n = 30;
    double a = 0, bnd = 3, h = (bnd - a) / (n - 1);
    vector<double> x(n);
    vector<vector<double>> D(n, vector<double>(n, 0));
    for (int i = 0; i < n; i++) {
        x[i] = a + i * h;
        D[i][0] = exp(x[i]);
    }
    for (int j = 1; j < n; j++)
        for (int i = 0; i < n - j; i++) D[i][j] = D[i + 1][j - 1] - D[i][j - 1];

    printf("(a) Forward differences at x0 (coefficients of P(x)):\n");
    for (int k = 0; k < n; k++) printf("Delta^%-2d f0 = % .6e\n", k, D[0][k]);

    double xp = 1.2, u = (xp - x[0]) / h, term = 1, P = D[0][0];
    for (int k = 1; k < n; k++) {
        term *= (u - k + 1) / k;
        P += term * D[0][k];
    }
    double ex = exp(xp);
    printf("\nh = %.6f, u = %.6f\n", h, u);
    printf("(b) P(1.2) = %.12f\n", P);
    printf("    Exact  = %.12f\n", ex);
    printf("(c) Absolute error = %.6e\n    Relative error = %.6e\n", fabs(ex - P), fabs(ex - P) / fabs(ex));
    return 0;
}
