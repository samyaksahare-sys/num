#include <bits/stdc++.h>
using namespace std;

double fl(double x) {
    if (x == 0 || !isfinite(x)) return x;
    double e = floor(log10(fabs(x)));
    double s = pow(10.0, 3 - e);
    return round(x * s) / s;
}

typedef vector<vector<double>> Mat;

double frob(const Mat& A) {
    double s = 0;
    for (auto& r : A) for (double v : r) s += v * v;
    return sqrt(s);
}

Mat inverse(Mat A) {
    int n = A.size();
    Mat I(n, vector<double>(n, 0));
    for (int i = 0; i < n; i++) I[i][i] = 1;
    for (int k = 0; k < n; k++) {
        int p = k;
        for (int i = k + 1; i < n; i++) if (fabs(A[i][k]) > fabs(A[p][k])) p = i;
        swap(A[k], A[p]);
        swap(I[k], I[p]);
        double d = A[k][k];
        for (int j = 0; j < n; j++) { A[k][j] /= d; I[k][j] /= d; }
        for (int i = 0; i < n; i++) if (i != k) {
            double m = A[i][k];
            for (int j = 0; j < n; j++) { A[i][j] -= m * A[k][j]; I[i][j] -= m * I[k][j]; }
        }
    }
    return I;
}

vector<double> solve(Mat A, vector<double> b, int mode, double& firstPivot) {
    int n = A.size();
    vector<int> col(n);
    iota(col.begin(), col.end(), 0);
    for (int k = 0; k < n; k++) {
        int pr = k, pc = k;
        if (mode >= 1) {
            for (int i = k; i < n; i++) {
                if (mode == 1) { if (fabs(A[i][k]) > fabs(A[pr][k])) pr = i; }
                else for (int j = k; j < n; j++) if (fabs(A[i][j]) > fabs(A[pr][pc])) { pr = i; pc = j; }
            }
        }
        swap(A[k], A[pr]);
        swap(b[k], b[pr]);
        if (pc != k) {
            for (int i = 0; i < n; i++) swap(A[i][k], A[i][pc]);
            swap(col[k], col[pc]);
        }
        if (k == 0) firstPivot = A[0][0];
        for (int i = k + 1; i < n; i++) {
            double m = fl(A[i][k] / A[k][k]);
            for (int j = k; j < n; j++) A[i][j] = fl(A[i][j] - fl(m * A[k][j]));
            b[i] = fl(b[i] - fl(m * b[k]));
        }
    }
    vector<double> y(n);
    for (int i = n - 1; i >= 0; i--) {
        double s = b[i];
        for (int j = i + 1; j < n; j++) s = fl(s - fl(A[i][j] * y[j]));
        y[i] = fl(s / A[i][i]);
    }
    vector<double> x(n);
    for (int i = 0; i < n; i++) x[col[i]] = y[i];
    return x;
}

int main() {
    Mat A = {{0.0001, 1, 1}, {1, 1, 2}, {2, 1, 1}};
    vector<double> b = {2.0001, 4, 4};
    vector<double> exact = {1, 1, 1};

    Mat Ai = inverse(A);
    double nA = frob(A), nAi = frob(Ai);
    printf("(a) ||A||_e = %.4f, ||A^-1||_e = %.4f, kappa(A) = %.4f\n\n", nA, nAi, nA * nAi);

    const char* names[] = {"No Pivoting", "Partial Pivoting", "Complete Pivoting"};
    printf("%-20s%-15s%-36s%-12s\n", "Strategy", "Initial Pivot", "Solution Vector", "Status");
    printf("-----------------------------------------------------------------------------------\n");
    for (int m = 0; m < 3; m++) {
        double piv;
        vector<double> x = solve(A, b, m, piv);
        double err = 0;
        for (int i = 0; i < 3; i++) err = isfinite(x[i]) ? max(err, fabs(x[i] - exact[i])) : 1e9;
        char buf[100];
        snprintf(buf, sizeof buf, "(%.4g, %.4g, %.4g)", x[0], x[1], x[2]);
        printf("%-20s%-15.4g%-36s%-12s\n", names[m], piv, buf, err < 1e-2 ? "Successful" : "Failed");
    }
    printf("\n(e) kappa(A) is moderate, so the problem itself is well-conditioned (structural conditioning).\n");
    printf("The failure without pivoting comes from the tiny pivot 0.0001 producing huge multipliers that\n");
    printf("destroy information in 4-digit arithmetic: an algorithmic instability, removed by pivoting.\n");
    return 0;
}
