#include <bits/stdc++.h>
using namespace std;

double f(double x) { return x * x * x + 4 * x * x - 10; }

struct Result { double root; int iters; double fx; double cpu; };

Result bisection(double a, double b, double tol, bool show) {
    clock_t st = clock();
    double c = a, prev = a;
    int it = 0;
    if (show) {
        printf("\nBisection Method\n%-6s%-16s%-16s%-16s\n", "Iter", "x_n", "f(x_n)", "Error");
        printf("------------------------------------------------------\n");
    }
    while (true) {
        c = (a + b) / 2;
        it++;
        if (show) printf("%-6d%-16.10f%-16.6e%-16.6e\n", it, c, f(c), it == 1 ? fabs(b - a) : fabs(c - prev));
        if (fabs(f(c)) < tol) break;
        if (f(a) * f(c) < 0) b = c;
        else a = c;
        prev = c;
    }
    clock_t en = clock();
    return {c, it, fabs(f(c)), (double)(en - st) / CLOCKS_PER_SEC};
}

Result regulaFalsi(double a, double b, double tol, bool show) {
    clock_t st = clock();
    double c = a, prev = a;
    int it = 0;
    if (show) {
        printf("\nRegula Falsi Method\n%-6s%-16s%-16s%-16s\n", "Iter", "x_n", "f(x_n)", "Error");
        printf("------------------------------------------------------\n");
    }
    while (true) {
        c = (a * f(b) - b * f(a)) / (f(b) - f(a));
        it++;
        if (show) printf("%-6d%-16.10f%-16.6e%-16.6e\n", it, c, f(c), it == 1 ? fabs(c - a) : fabs(c - prev));
        if (fabs(f(c)) < tol) break;
        if (f(a) * f(c) < 0) b = c;
        else a = c;
        prev = c;
    }
    clock_t en = clock();
    return {c, it, fabs(f(c)), (double)(en - st) / CLOCKS_PER_SEC};
}

int main() {
    double a = 1, b = 2, tol = 1e-6;
    Result r1 = bisection(a, b, tol, true);
    Result r2 = regulaFalsi(a, b, tol, true);
    int reps = 100000;
    clock_t s = clock();
    for (int i = 0; i < reps; i++) bisection(a, b, tol, false);
    r1.cpu = (double)(clock() - s) / CLOCKS_PER_SEC / reps;
    s = clock();
    for (int i = 0; i < reps; i++) regulaFalsi(a, b, tol, false);
    r2.cpu = (double)(clock() - s) / CLOCKS_PER_SEC / reps;
    printf("\n%-15s%-18s%-12s%-16s%-16s\n", "Method", "Approx Root", "Iterations", "|f(x)|", "CPU Time (s)");
    printf("-----------------------------------------------------------------------------\n");
    printf("%-15s%-18.10f%-12d%-16.6e%-16.6e\n", "Bisection", r1.root, r1.iters, r1.fx, r1.cpu);
    printf("%-15s%-18.10f%-12d%-16.6e%-16.6e\n", "Regula Falsi", r2.root, r2.iters, r2.fx, r2.cpu);
    printf("\n%s converges faster (fewer iterations).\n", r2.iters < r1.iters ? "Regula Falsi" : "Bisection");
    printf("Reason: Regula Falsi uses function values to place the new point (linear interpolation),\n");
    printf("while Bisection only halves the interval and ignores the magnitude of f.\n");
    return 0;
}
