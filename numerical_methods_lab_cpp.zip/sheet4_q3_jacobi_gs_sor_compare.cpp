#include <bits/stdc++.h>
using namespace std;

typedef vector<vector<double>> Mat;
typedef vector<double> Vec;

void printMat(const Mat& M) {
    for (auto& r : M) {
        for (double v : r) printf("%10.5f", v);
        printf("\n");
    }
}

int solve(const Mat& A, const Vec& b, int type, double w, double tol, Vec& x) {
    int n = A.size();
    x.assign(n, 0);
    for (int k = 1; k <= 10000; k++) {
        Vec old = x;
        double d = 0;
        for (int i = 0; i < n; i++) {
            double s = b[i];
            for (int j = 0; j < n; j++) if (j != i) s -= A[i][j] * (type == 0 ? old[j] : x[j]);
            double gs = s / A[i][i];
            x[i] = type == 2 ? (1 - w) * x[i] + w * gs : gs;
        }
        for (int i = 0; i < n; i++) d = max(d, fabs(x[i] - old[i]));
        if (d < tol) return k;
    }
    return -1;
}

int main() {
    Mat A = {{4, 1, -1, 1, 0}, {1, 5, 2, 0, 1}, {-1, 2, 5, 1, 1}, {1, 0, 1, 4, 2}, {0, 1, 1, 2, 5}};
    Vec b = {9.5, -4, -0.5, 10.5, -4.5};
    int n = 5;
    double tol = 1e-5;

    Mat TJ(n, Vec(n, 0));
    for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) if (i != j) TJ[i][j] = -A[i][j] / A[i][i];
    printf("(a) Gauss-Jacobi iteration matrix T_J = -D^-1(L+U):\n");
    printMat(TJ);

    Mat T(n, Vec(n, 0));
    for (int c = 0; c < n; c++) {
        Vec u(n, 0), z(n, 0);
        for (int i = 0; i < c; i++) u[i] = -A[i][c];
        for (int i = 0; i < n; i++) {
            double s = u[i];
            for (int j = 0; j < i; j++) s -= A[i][j] * z[j];
            z[i] = s / A[i][i];
        }
        for (int i = 0; i < n; i++) T[i][c] = z[i];
    }
    printf("\n(b) Gauss-Seidel iteration matrix T_G = -(D+L)^-1 U:\n");
    printMat(T);

    double eig[] = {-0.7605, 0.7294, -0.2445, -0.0824, 0.3579}, rho = 0;
    for (double e : eig) rho = max(rho, fabs(e));
    double wopt = 2 / (1 + sqrt(1 - rho * rho));
    printf("\n(c) rho(T_J) = %.4f, omega_opt = %.6f\n", rho, wopt);

    const char* nm[] = {"Jacobi", "Gauss-Seidel", "SOR"};
    int its[3];
    Vec xs[3];
    for (int t = 0; t < 3; t++) its[t] = solve(A, b, t, wopt, tol, xs[t]);
    int ord[3] = {0, 1, 2};
    sort(ord, ord + 3, [&](int a, int c) { return its[a] < its[c]; });
    int rank[3];
    for (int i = 0; i < 3; i++) rank[ord[i]] = i + 1;

    printf("\n(d)\n%-15s%-12s%-6s%s\n", "Method", "Iterations", "Rank", "Solution vector");
    printf("-----------------------------------------------------------------------------\n");
    for (int t = 0; t < 3; t++) {
        printf("%-15s%-12d%-6d(", nm[t], its[t], rank[t]);
        for (int i = 0; i < n; i++) printf("%.6f%s", xs[t][i], i < n - 1 ? ", " : ")\n");
    }
    printf("\nExact solution: (2, -1, 0.5, 3, -2)\n");
    return 0;
}
