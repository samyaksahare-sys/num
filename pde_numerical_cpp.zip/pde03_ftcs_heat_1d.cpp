#include <bits/stdc++.h>
using namespace std;

double phi(double x) { return 4 * x - x * x; }

int main() {
    double alpha2 = 0.5, a = 0, b = 4, dx = 1, dt = 0.5;
    int M = round((b - a) / dx), steps = 4;
    double lam = alpha2 * dt / (dx * dx);
    printf("u_t = %.2f u_xx, u(x,0) = 4x - x^2, u(0,t) = u(4,t) = 0\n", alpha2);
    printf("dx = %g, dt = %g, lambda = %g %s\n\n", dx, dt, lam, lam <= 0.5 ? "(stable)" : "(UNSTABLE)");

    vector<double> u(M + 1), nu(M + 1);
    for (int i = 0; i <= M; i++) u[i] = phi(a + i * dx);
    u[0] = u[M] = 0;

    printf("%-8s", "t\\x");
    for (int i = 0; i <= M; i++) printf("%-12g", a + i * dx);
    printf("\n");
    for (int n = 0; n <= steps; n++) {
        printf("%-8g", n * dt);
        for (double v : u) printf("%-12.6f", v);
        printf("\n");
        for (int i = 1; i < M; i++) nu[i] = lam * u[i + 1] + (1 - 2 * lam) * u[i] + lam * u[i - 1];
        nu[0] = nu[M] = 0;
        u = nu;
    }
    return 0;
}
