#include <bits/stdc++.h>
using namespace std;

double phi(double x) { return x * x * (3 - x); }

vector<double> thomas(vector<double> a, vector<double> b, vector<double> c, vector<double> d) {
    int n = b.size();
    for (int i = 1; i < n; i++) {
        double m = a[i] / b[i - 1];
        b[i] -= m * c[i - 1];
        d[i] -= m * d[i - 1];
    }
    vector<double> x(n);
    x[n - 1] = d[n - 1] / b[n - 1];
    for (int i = n - 2; i >= 0; i--) x[i] = (d[i] - c[i] * x[i + 1]) / b[i];
    return x;
}

int main() {
    double alpha2 = 4, a = 0, b = 3, dx = 1, dt = 0.5, flux = 0, gR = 0;
    int M = round((b - a) / dx), steps = 3, m = M - 1;
    double lam = alpha2 * dt / (dx * dx), h = lam / 2;
    double c0 = -2.0 / 3 * flux * dx;
    printf("u_t = 4u_xx, u(x,0) = x^2(3-x), u_x(0,t) = %g, u(3,t) = %g\n", flux, gR);
    printf("dx = %g, dt = %g, lambda = %g, u_0 = (4/3)u_1 - (1/3)u_2\n\n", dx, dt, lam);

    vector<double> u(M + 1);
    for (int i = 0; i <= M; i++) u[i] = phi(a + i * dx);
    u[M] = gR;
    u[0] = 4.0 / 3 * u[1] - u[2] / 3 + c0;

    printf("%-8s", "t\\x");
    for (int i = 0; i <= M; i++) printf("%-12g", a + i * dx);
    printf("\n");
    for (int n = 0; n <= steps; n++) {
        printf("%-8g", n * dt);
        for (double v : u) printf("%-12.6f", fabs(v) < 1e-12 ? 0.0 : v);
        printf("\n");
        vector<double> A(m, -h), B(m, 1 + lam), C(m, -h), D(m);
        for (int i = 1; i < M; i++) D[i - 1] = h * u[i - 1] + (1 - lam) * u[i] + h * u[i + 1];
        B[0] += -h * 4.0 / 3;
        C[0] += h / 3;
        D[0] += h * c0;
        D[m - 1] += h * gR;
        vector<double> x = thomas(A, B, C, D);
        for (int i = 0; i < m; i++) u[i + 1] = x[i];
        u[0] = 4.0 / 3 * u[1] - u[2] / 3 + c0;
    }
    return 0;
}
