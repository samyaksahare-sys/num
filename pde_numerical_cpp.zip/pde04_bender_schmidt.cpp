#include <bits/stdc++.h>
using namespace std;

double phi(double x) { return 4 * x - x * x; }

int main() {
    double alpha2 = 0.5, a = 0, b = 4, dx = 1;
    double dt = dx * dx / (2 * alpha2);
    int M = round((b - a) / dx), steps = 5;
    printf("Bender-Schmidt (lambda = 1/2): u_i^(n+1) = (u_(i-1)^n + u_(i+1)^n) / 2\n");
    printf("u_t = %.2f u_xx, dx = %g, dt = %g\n\n", alpha2, dx, dt);

    vector<double> u(M + 1), nu(M + 1, 0);
    for (int i = 0; i <= M; i++) u[i] = phi(a + i * dx);
    u[0] = u[M] = 0;

    printf("%-8s", "t\\x");
    for (int i = 0; i <= M; i++) printf("%-12g", a + i * dx);
    printf("\n");
    for (int n = 0; n <= steps; n++) {
        printf("%-8g", n * dt);
        for (double v : u) printf("%-12.6f", v);
        printf("\n");
        for (int i = 1; i < M; i++) nu[i] = (u[i - 1] + u[i + 1]) / 2;
        u = nu;
    }
    return 0;
}
