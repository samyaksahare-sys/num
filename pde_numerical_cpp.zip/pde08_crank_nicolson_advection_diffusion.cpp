#include <bits/stdc++.h>
using namespace std;

double phi(double x) { return 4 * x - x * x; }

vector<double> thomas(vector<double> a, vector<double> b, vector<double> c, vector<double> d) {
    int n = b.size();
    for (int i = 1; i < n; i++) {
        double m = a[i] / b[i - 1];
        b[i] -= m * c[i - 1];
        d[i] -= m * d[i - 1];
    }
    vector<double> x(n);
    x[n - 1] = d[n - 1] / b[n - 1];
    for (int i = n - 2; i >= 0; i--) x[i] = (d[i] - c[i] * x[i + 1]) / b[i];
    return x;
}

int main() {
    double alpha2 = 0.5, K = 1, a = 0, b = 4, dx = 0.5, dt = 0.25, gL = 0, gR = 0;
    int M = round((b - a) / dx), steps = 4, m = M - 1;
    double lam = alpha2 * dt / (dx * dx), mu = K * dt / dx;
    double L = -lam / 2 + mu / 4, Dg = 1 + lam, R = -(lam / 2 + mu / 4);
    double rl = lam / 2 - mu / 4, rc = 1 - lam, rr = lam / 2 + mu / 4;
    printf("u_t = %g u_xx + %g u_x, lambda = %g, mu = %g\n", alpha2, K, lam, mu);
    printf("(-l/2+m/4)u_(i-1)^(n+1) + (1+l)u_i^(n+1) - (l/2+m/4)u_(i+1)^(n+1)\n");
    printf("  = (l/2-m/4)u_(i-1)^n + (1-l)u_i^n + (l/2+m/4)u_(i+1)^n\n\n");

    vector<double> u(M + 1);
    for (int i = 0; i <= M; i++) u[i] = phi(a + i * dx);
    u[0] = gL;
    u[M] = gR;

    printf("%-8s", "t\\x");
    for (int i = 0; i <= M; i++) printf("%-10g", a + i * dx);
    printf("\n");
    for (int n = 0; n <= steps; n++) {
        printf("%-8g", n * dt);
        for (double v : u) printf("%-10.5f", v);
        printf("\n");
        vector<double> A(m, L), B(m, Dg), C(m, R), D(m);
        for (int i = 1; i < M; i++) D[i - 1] = rl * u[i - 1] + rc * u[i] + rr * u[i + 1];
        D[0] -= L * gL;
        D[m - 1] -= R * gR;
        vector<double> x = thomas(A, B, C, D);
        for (int i = 0; i < m; i++) u[i + 1] = x[i];
    }
    return 0;
}
