#include <bits/stdc++.h>
using namespace std;

double phi(double x) { return 4 * x - x * x; }

vector<double> thomas(vector<double> a, vector<double> b, vector<double> c, vector<double> d) {
    int n = b.size();
    for (int i = 1; i < n; i++) {
        double m = a[i] / b[i - 1];
        b[i] -= m * c[i - 1];
        d[i] -= m * d[i - 1];
    }
    vector<double> x(n);
    x[n - 1] = d[n - 1] / b[n - 1];
    for (int i = n - 2; i >= 0; i--) x[i] = (d[i] - c[i] * x[i + 1]) / b[i];
    return x;
}

int main() {
    double alpha2 = 0.5, a = 0, b = 4, dx = 1, dt = 0.5, gL = 0, gR = 0;
    int M = round((b - a) / dx), steps = 4, m = M - 1;
    double lam = alpha2 * dt / (dx * dx);
    printf("Crank-Nicolson: -(l/2)u_(i-1)^(n+1) + (1+l)u_i^(n+1) - (l/2)u_(i+1)^(n+1)\n");
    printf("               = (l/2)u_(i-1)^n + (1-l)u_i^n + (l/2)u_(i+1)^n,  lambda = %g\n\n", lam);

    vector<double> u(M + 1);
    for (int i = 0; i <= M; i++) u[i] = phi(a + i * dx);
    u[0] = gL;
    u[M] = gR;

    printf("%-8s", "t\\x");
    for (int i = 0; i <= M; i++) printf("%-12g", a + i * dx);
    printf("\n");
    for (int n = 0; n <= steps; n++) {
        printf("%-8g", n * dt);
        for (double v : u) printf("%-12.6f", v);
        printf("\n");
        vector<double> A(m, -lam / 2), B(m, 1 + lam), C(m, -lam / 2), D(m);
        for (int i = 1; i < M; i++) D[i - 1] = lam / 2 * u[i - 1] + (1 - lam) * u[i] + lam / 2 * u[i + 1];
        D[0] += lam / 2 * gL;
        D[m - 1] += lam / 2 * gR;
        vector<double> x = thomas(A, B, C, D);
        for (int i = 0; i < m; i++) u[i + 1] = x[i];
    }
    return 0;
}
