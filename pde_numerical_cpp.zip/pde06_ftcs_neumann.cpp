#include <bits/stdc++.h>
using namespace std;

double phi(double x) { return 4 * x - x * x; }

int main() {
    double alpha2 = 0.5, a = 0, b = 4, dx = 1, dt = 0.5, flux = 0, gR = 0;
    int M = round((b - a) / dx), steps = 4;
    double lam = alpha2 * dt / (dx * dx);
    printf("u_t = %.2f u_xx, u(x,0) = 4x - x^2, u_x(0,t) = %g, u(4,t) = %g\n", alpha2, flux, gR);
    printf("u_0 = (4/3)u_1 - (1/3)u_2 - (2/3) a dx,  lambda = %g\n\n", lam);

    vector<double> u(M + 1), nu(M + 1);
    for (int i = 0; i <= M; i++) u[i] = phi(a + i * dx);
    u[M] = gR;
    u[0] = 4.0 / 3 * u[1] - u[2] / 3 - 2.0 / 3 * flux * dx;

    printf("%-8s", "t\\x");
    for (int i = 0; i <= M; i++) printf("%-12g", a + i * dx);
    printf("\n");
    for (int n = 0; n <= steps; n++) {
        printf("%-8g", n * dt);
        for (double v : u) printf("%-12.6f", v);
        printf("\n");
        for (int i = 1; i < M; i++) nu[i] = lam * u[i + 1] + (1 - 2 * lam) * u[i] + lam * u[i - 1];
        nu[M] = gR;
        nu[0] = 4.0 / 3 * nu[1] - nu[2] / 3 - 2.0 / 3 * flux * dx;
        u = nu;
    }
    return 0;
}
