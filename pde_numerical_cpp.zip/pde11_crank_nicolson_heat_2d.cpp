#include <bits/stdc++.h>
using namespace std;

double f(double x, double y) { return sin(M_PI * x) * sin(M_PI * y); }

void show(const vector<vector<double>>& u, double t) {
    int I = u.size() - 1, J = u[0].size() - 1;
    printf("t = %.3f\n", t);
    for (int j = J; j >= 0; j--) {
        for (int i = 0; i <= I; i++) printf("%-12.7f", u[i][j]);
        printf("\n");
    }
    printf("\n");
}

int main() {
    double alpha2 = 1, Lx = 1, Ly = 1, dx = 0.25, dy = 0.25, dt = 0.01, tol = 1e-10;
    int I = round(Lx / dx), J = round(Ly / dy), steps = 3;
    double lx = alpha2 * dt / (dx * dx), ly = alpha2 * dt / (dy * dy);
    printf("Crank-Nicolson 2D (system solved by Gauss-Seidel), lx = %g, ly = %g\n", lx, ly);
    printf("(1+lx+ly)u_ij^(n+1) - lx/2(u_(i+1)j + u_(i-1)j)^(n+1) - ly/2(u_i(j+1) + u_i(j-1))^(n+1)\n");
    printf("  = lx/2(u_(i+1)j + u_(i-1)j)^n + ly/2(u_i(j+1) + u_i(j-1))^n + (1-lx-ly)u_ij^n\n\n");

    vector<vector<double>> u(I + 1, vector<double>(J + 1, 0));
    for (int i = 1; i < I; i++)
        for (int j = 1; j < J; j++) u[i][j] = f(i * dx, j * dy);
    show(u, 0);
    for (int n = 1; n <= steps; n++) {
        vector<vector<double>> rhs(I + 1, vector<double>(J + 1, 0)), nu = u;
        for (int i = 1; i < I; i++)
            for (int j = 1; j < J; j++)
                rhs[i][j] = lx / 2 * (u[i + 1][j] + u[i - 1][j]) + ly / 2 * (u[i][j + 1] + u[i][j - 1]) + (1 - lx - ly) * u[i][j];
        int it = 0;
        while (true) {
            double d = 0;
            for (int i = 1; i < I; i++)
                for (int j = 1; j < J; j++) {
                    double v = (rhs[i][j] + lx / 2 * (nu[i + 1][j] + nu[i - 1][j]) + ly / 2 * (nu[i][j + 1] + nu[i][j - 1])) / (1 + lx + ly);
                    d = max(d, fabs(v - nu[i][j]));
                    nu[i][j] = v;
                }
            it++;
            if (d < tol) break;
        }
        u = nu;
        printf("(Gauss-Seidel iterations: %d)\n", it);
        show(u, n * dt);
    }
    return 0;
}
