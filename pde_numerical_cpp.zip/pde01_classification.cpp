#include <bits/stdc++.h>
using namespace std;

string classify(double A, double B, double C) {
    double d = B * B - 4 * A * C;
    if (d < 0) return "Elliptic";
    if (d == 0) return "Parabolic";
    return "Hyperbolic";
}

int main() {
    vector<tuple<string, double, double, double>> ex = {
        {"Laplace  u_xx + u_yy = 0", 1, 0, 1},
        {"Heat     u_t = u_xx", 1, 0, 0},
        {"Wave     u_tt = u_xx", 1, 0, -1},
        {"u_xx + 4u_xy + 4u_yy = 0", 1, 4, 4},
        {"u_xx + 3u_xy + u_yy = 0", 1, 3, 1}};
    printf("%-30s%-6s%-6s%-6s%-12s%-12s\n", "Equation", "A", "B", "C", "B^2-4AC", "Type");
    for (auto& [s, A, B, C] : ex)
        printf("%-30s%-6g%-6g%-6g%-12g%-12s\n", s.c_str(), A, B, C, B * B - 4 * A * C, classify(A, B, C).c_str());

    double A, B, C;
    printf("\nEnter A B C: ");
    if (cin >> A >> B >> C) printf("B^2-4AC = %g -> %s\n", B * B - 4 * A * C, classify(A, B, C).c_str());
    return 0;
}
