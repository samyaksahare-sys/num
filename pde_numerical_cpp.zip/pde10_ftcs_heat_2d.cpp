#include <bits/stdc++.h>
using namespace std;

double f(double x, double y) { return sin(M_PI * x) * sin(M_PI * y); }

void show(const vector<vector<double>>& u, double t) {
    int I = u.size() - 1, J = u[0].size() - 1;
    printf("t = %.3f\n", t);
    for (int j = J; j >= 0; j--) {
        for (int i = 0; i <= I; i++) printf("%-12.7f", u[i][j]);
        printf("\n");
    }
    printf("\n");
}

int main() {
    double alpha2 = 1, Lx = 1, Ly = 1, dx = 0.25, dy = 0.25;
    double dtMax = dx * dx * dy * dy / (2 * alpha2 * (dx * dx + dy * dy)), dt = 0.01;
    int I = round(Lx / dx), J = round(Ly / dy), steps = 3;
    double lx = alpha2 * dt / (dx * dx), ly = alpha2 * dt / (dy * dy);
    printf("u_t = u_xx + u_yy, u = 0 on boundary, u(x,y,0) = sin(pi x) sin(pi y)\n");
    printf("dx = dy = %g, stability: dt <= %g, using dt = %g, lx = %g, ly = %g\n\n", dx, dtMax, dt, lx, ly);

    vector<vector<double>> u(I + 1, vector<double>(J + 1, 0)), nu = u;
    for (int i = 1; i < I; i++)
        for (int j = 1; j < J; j++) u[i][j] = f(i * dx, j * dy);
    show(u, 0);
    for (int n = 1; n <= steps; n++) {
        for (int i = 1; i < I; i++)
            for (int j = 1; j < J; j++)
                nu[i][j] = lx * (u[i - 1][j] + u[i + 1][j]) + ly * (u[i][j - 1] + u[i][j + 1]) + (1 - 2 * lx - 2 * ly) * u[i][j];
        u = nu;
        show(u, n * dt);
    }
    return 0;
}
