#include <bits/stdc++.h>
using namespace std;

double u(double x, double y) { return sin(x) * exp(y); }

int main() {
    double x = 1.0, y = 0.5, h = 0.01, k = 0.01;
    double ux = (u(x + h, y) - u(x - h, y)) / (2 * h);
    double uy = (u(x, y + k) - u(x, y - k)) / (2 * k);
    double uxx = (u(x + h, y) - 2 * u(x, y) + u(x - h, y)) / (h * h);
    double uyy = (u(x, y + k) - 2 * u(x, y) + u(x, y - k)) / (k * k);
    double uxy = (u(x + h, y + k) - u(x + h, y - k) - u(x - h, y + k) + u(x - h, y - k)) / (4 * h * k);

    double ex[] = {cos(x) * exp(y), sin(x) * exp(y), -sin(x) * exp(y), sin(x) * exp(y), cos(x) * exp(y)};
    double ap[] = {ux, uy, uxx, uyy, uxy};
    const char* nm[] = {"u_x", "u_y", "u_xx", "u_yy", "u_xy"};
    printf("u(x,y) = sin(x) e^y at (%.2f, %.2f), h = %.2f, k = %.2f\n\n", x, y, h, k);
    printf("%-8s%-18s%-18s%-14s\n", "Deriv", "Finite Diff", "Exact", "Abs Error");
    for (int i = 0; i < 5; i++) printf("%-8s%-18.10f%-18.10f%-14.6e\n", nm[i], ap[i], ex[i], fabs(ap[i] - ex[i]));
    return 0;
}
